package MAIN;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

import org.antlr.v4.runtime.RuleContext;
import org.antlr.v4.runtime.tree.TerminalNodeImpl;

import ANTLR.LexerT;
import ANTLR.ParserTBaseVisitor;
import ANTLR.ParserTParser;

public class MyVisitor extends ParserTBaseVisitor<Integer> {
	
	Map<String, String> variables = new HashMap<String, String>();
	Map<String, Boolean> variablesEstaticas = new HashMap<String, Boolean>(); //Colocar

	public String tokenName(Object nodo) {
		if (nodo instanceof TerminalNodeImpl) {
			TerminalNodeImpl nodoTerminal = ((TerminalNodeImpl) nodo);
			return LexerT.VOCABULARY.getSymbolicName(nodoTerminal.getSymbol().getType());
		}
		RuleContext nodoTerminal = (RuleContext) nodo;
		String nombre = nodoTerminal.getClass().getSimpleName();
		return nombre.substring(0, nombre.length() - 7);
	}
	
	//Verifica si es un String con formato "string"
	public boolean isString(String str) {
        return str.contains("\"");
    }
	
	//Verifica si es un número como int o float
	public boolean isNumber(String str) {
		
        if (str == null || str.isEmpty()) {
            return false;
        }

        boolean punto = false;
        boolean hayDigit = false;
        for (char c : str.toCharArray()) {
        	//Valida si solo hay caracteres numéricos
            if (Character.isDigit(c)) {
            	hayDigit = true;
            } else if (c == '.') {
            	//Valida si se repite algun punto decimal
                if (punto) {
                    return false; 
                }
                punto = true;
            } else {
                return false;
            }
        }

        return hayDigit;
	    
    }
	
	//Elimina las comillas dobles al inicio y al final del String
	public String formatString(String str) {
        if (str.length() <= 1) {
            return "";
        } else {
            return str.substring(1, str.length() - 1);
        }
    }
	
	//Verifica que condición se realiza
	public boolean condicion(ParserTParser.CondicionContext ctx) {
		
		//Obtenemos las variables involucradas en la condición
		String varIzquierda = ctx.getChild(0).getChild(1).getText();
		String varDerecha = ctx.getChild(0).getChild(3).getText();
		
		//Obtener su valor correspondiente del mapa
		String valueIzquierda = variables.get(varIzquierda);
		String valueDerecha = variables.get(varDerecha);
		
		//Valida que ningún valor sea null
		if(valueIzquierda == null || valueDerecha == null) {
			System.err.println("ERROR NO EXISTE ALGUNA DE LAS VARIABLES "+varIzquierda+" o "+varDerecha+" INVOLUCRADAS EN LA CONDICIÓN");
			System.exit(1);
		}
		
		//Validar si las variables son distinto tipo de objetos
		if((isString(valueIzquierda) && isNumber(valueDerecha)) || (isNumber(valueIzquierda) && isString(valueDerecha))) {
			System.err.println("ERROR DE COMPARACIÓN LAS VARIABLES "+varIzquierda+" y "+varDerecha+" NO SON EL MISMO TIPO DE OBJETO");
			System.exit(1);
		}
		
		//Validar si ambos son strings o números
		boolean varSonStrings = isString(valueIzquierda);
		
		//Validar que clase de condición realizar
		if(tokenName(ctx.getChild(0)).equals("Mayor")) {
			if(varSonStrings) {
				return valueIzquierda.compareTo(valueDerecha) > 0;
			}
			else {
				return Float.parseFloat(valueIzquierda) > Float.parseFloat(valueDerecha);
			}
		}
		if(tokenName(ctx.getChild(0)).equals("Menor")) {
			if(varSonStrings) {
				return valueIzquierda.compareTo(valueDerecha) < 0;
			}
			else {
				return Float.parseFloat(valueIzquierda) < Float.parseFloat(valueDerecha);
			}
		}
		if(tokenName(ctx.getChild(0)).equals("Distinto")) {
			if(varSonStrings) {
				return !(valueIzquierda.equals(valueDerecha));
			}
			else {
				return Float.parseFloat(valueIzquierda) != Float.parseFloat(valueDerecha);
			}
		}
		if(tokenName(ctx.getChild(0)).equals("Igual")) {
			if(varSonStrings) {
				return valueIzquierda.equals(valueDerecha);
			}
			else {
				return Float.parseFloat(valueIzquierda) == Float.parseFloat(valueDerecha);
			}
		}
		return false;
	}
	
	//Verifica el valor de verdad de la afirmación
	public boolean afirmacion(ParserTParser.AfirmacionContext ctx) {
		//Obtener la condición inicial
		boolean cond1 = condicion((ParserTParser.CondicionContext) ctx.getChild(0));
		boolean cond2;
		
		//Iterar cada 2 nodos para ir actualizando la condición inicial
		for (int i = 1; i < ctx.getChildCount(); i+=2) {
			cond2 = condicion((ParserTParser.CondicionContext) ctx.getChild(i+1));
			if (ctx.getChild(i).getText().equals("y")){
				cond1 = cond1 && cond2;
			}
			if (ctx.getChild(i).getText().equals("o")){
				cond1 = cond1 || cond2;
			}
		}
		return cond1;
	}
	
	@Override
	public Integer visitObjeto(ParserTParser.ObjetoContext ctx) {
		
		boolean esEstatica;
		int variableIndice;
		String variable = null;
		//Valida si comienza con Declare_constante
		if(tokenName(ctx.getChild(0)).equals("Declare_constante")){
			esEstatica = true;
			variableIndice = 1;
		}
		else {
			esEstatica = false;
			variableIndice = 0;
		}
		
		//Obtiene la variable para asignar el valor de verdad si es estática o no
		if(tokenName(ctx.getChild(variableIndice)).equals("Entero")){
			variable = ctx.getChild(variableIndice).getChild(1).getText();
		}
		if(tokenName(ctx.getChild(variableIndice)).equals("Decimal")){
			variable = ctx.getChild(variableIndice).getChild(2).getText();
		}
		if(tokenName(ctx.getChild(variableIndice)).equals("String")){
			variable = ctx.getChild(variableIndice).getChild(0).getText();
		}
		System.out.println("Estática? = "+variable +"-"+ esEstatica);
		variablesEstaticas.put(variable, esEstatica);
	
		return visitChildren(ctx);
	}
	
	@Override
	public Integer visitEntero(ParserTParser.EnteroContext ctx) {
		
		String variable, valor;
		
		variable = ctx.getChild(1).getText();
		valor = ctx.getChild(0).getText();
		
		//Ingresar la variable a los mapas solo si no existen
		if(variables.get(variable) == null) {
			System.out.println("Ingresando = "+variable +"-"+ valor);
			variables.put(variable,valor);
		}
		else {
			System.err.println("ERROR LA VARIABLE "+variable+" YA FUE DECLARADA");
			System.exit(1);
		}
	
		return 0;
	}
	
	@Override
	public Integer visitDecimal(ParserTParser.DecimalContext ctx) {
		
		String variable, valor;
		
		variable = ctx.getChild(2).getText();
		valor = ctx.getChild(0).getText();
		
		//Valida si son constantes (Pi o Fi)
		if(ctx.getChild(0).getText().equals("Fi")) {
			valor = "1.618";
		}
		if(ctx.getChild(0).getText().equals("Pi")) {
			valor = "3.14";
		}
		
		//Ingresar la variable a los mapas solo si no existen
		if(variables.get(variable) == null) {
			System.out.println("Ingresando = "+variable +"-"+ valor);
			variables.put(variable,valor);
		}
		else {
			System.err.println("ERROR LA VARIABLE "+variable+" YA FUE DECLARADA");
			System.exit(1);
		}
	
		return 0;
	}
	
	@Override
	public Integer visitString(ParserTParser.StringContext ctx) {
		
		String variable, valor;
		
		variable = ctx.getChild(0).getText();
		valor = ctx.getChild(2).getText();
		
		//Ingresar la variable a los mapas solo si no existen
		if(variables.get(variable) == null) {
			System.out.println("Ingresando = "+variable +"-"+ valor);
			variables.put(variable,valor);
		}
		else {
			System.err.println("ERROR LA VARIABLE "+variable+" YA FUE DECLARADA");
			System.exit(1);
		}
	
		return 0;
	}
	
	@Override
	public Integer visitOperacion(ParserTParser.OperacionContext ctx) {
		//Obtener la variable objetivo que depende del nodo opcional "Resultado"
		String variableObjetivo;
		if(ctx.getChild(0).getChild(4) != null) {
			variableObjetivo = ctx.getChild(0).getChild(4).getChild(1).getText();
		}
		else{
			variableObjetivo = ctx.getChild(0).getChild(1).getText();
		}
		
		//Validar que la variable objetivo no sea estática
		if(variables.get(variableObjetivo) != null && variablesEstaticas.get(variableObjetivo)) {
			System.err.println("ERROR LA VARIABLE OBJETIVO "+variableObjetivo+" ES ESTÁTICA");
			System.exit(1);
		}
		
		//Obtenemos las variables involucradas en la operación
		String varIzquierda = ctx.getChild(0).getChild(1).getText();
		String varDerecha = ctx.getChild(0).getChild(3).getText();
		
		//Obtener su valor correspondiente del mapa
		String valueIzquierda = variables.get(varIzquierda);
		String valueDerecha = variables.get(varDerecha);
		
		//Valida que ningún valor sea null
		if(valueIzquierda == null || valueDerecha == null) {
			System.err.println("ERROR NO EXISTE ALGUNA DE LAS VARIABLES "+varIzquierda+" o "+varDerecha+" INVOLUCRADAS EN LA OPERACIÓN");
			System.exit(1);
		}
		
		//Valida que ningún valor sea String (que no contenga '"')
		if(isString(valueIzquierda) | isString(valueDerecha)) {
			System.err.println("ERROR ALGUNA DE LAS VARIABLES "+varIzquierda+" o "+varDerecha+" INVOLUCRADAS EN LA OPERACIÓN ES UN STRING");
			System.exit(1);
		}
		
		//Realizar la operación
		float operacion = 0;
		if(tokenName(ctx.getChild(0)).equals("Suma")) {
			operacion = Float.parseFloat(valueIzquierda) + Float.parseFloat(valueDerecha);
		}
		if(tokenName(ctx.getChild(0)).equals("Resta")) {
			operacion = Float.parseFloat(valueIzquierda) - Float.parseFloat(valueDerecha);
		}
		if(tokenName(ctx.getChild(0)).equals("Multiplicacion")) {
			operacion = Float.parseFloat(valueIzquierda) * Float.parseFloat(valueDerecha);
		}
		if(tokenName(ctx.getChild(0)).equals("Division")) {
			operacion = Float.parseFloat(valueIzquierda) / Float.parseFloat(valueDerecha);
		}
		
		//Si no se encontraba en el mapa se agrega al de variables estáticas y no estáticas
		if(variables.get(variableObjetivo) == null) {
			variablesEstaticas.put(variableObjetivo, false);
		}
		System.out.println("Operación = "+variableObjetivo+"-"+Float.toString(operacion));
		variables.put(variableObjetivo, Float.toString(operacion));
		
		return 0;
		
	}
	
	@Override
	public Integer visitFuncion(ParserTParser.FuncionContext ctx) {
		//Obtener la variable objetivo que depende del nodo opcional "Resultado"
		String variableObjetivo;
		if(ctx.getChild(2) != null) {
			variableObjetivo = ctx.getChild(2).getChild(1).getText();
		}
		else{
			variableObjetivo = ctx.getChild(1).getText();
		}
		
		//Validar que la variable objetivo no sea estática
		if(variables.get(variableObjetivo) != null && variablesEstaticas.get(variableObjetivo)) {
			System.err.println("ERROR LA VARIABLE OBJETIVO "+variableObjetivo+" ES ESTÁTICA");
			System.exit(1);
		}
		
		//Obtenemos la variable involucrada en la función
		String var = ctx.getChild(1).getText();
		
		//Obtener su valor correspondiente del mapa
		String value = variables.get(var);
		
		//Valida que el valor no sea null
		if(value == null) {
			System.err.println("ERROR NO EXISTE LA VARIABLE "+var+" INVOLUCRADA EN LA FUNCIÓN");
			System.exit(1);
		}
		
		//Valida que el valor no sea un String (que no contenga '"')
		if(isString(value)) {
			System.err.println("ERROR LA VARIABLE "+var+" INVOLUCRADA EN LA FUNCIÓN ES UN STRING");
			System.exit(1);
		}
		
		//Realizar la operación
		float funcion = 0;
		if(ctx.getChild(0).getText().equals("Cuadrar")) {
			funcion = (float) Math.sqrt(Float.parseFloat(value)) ;
		}
		if(ctx.getChild(0).getText().equals("Centrar")) {
			funcion = (float) Math.sin(Float.parseFloat(value)) ;
		}
		if(ctx.getChild(0).getText().equals("Cortar")) {
			funcion = (float) Math.cos(Float.parseFloat(value)) ;
		}
		
		//Si no se encontraba en el mapa se agrega al de variables estáticas y no estáticas
		if(variables.get(variableObjetivo) == null) {
			variablesEstaticas.put(variableObjetivo, false);
		}
		System.out.println("Función = "+variableObjetivo+"-"+Float.toString(funcion));
		variables.put(variableObjetivo, Float.toString(funcion));
		
		return 0;
	}
	
	@Override
	public Integer visitOutput(ParserTParser.OutputContext ctx) {
		
		//Validar si la oración es un String o una variable
		String var = ctx.getChild(1).getChild(0).getText();
		if(isString(var)) {
			System.out.println(formatString(var));
		}
		else {
			//Validar si el valor existe o no
			if(variables.get(var) != null) {
				
				//Validar si el valor es String o no
				if(isString(variables.get(var))) {
					System.out.println(formatString(variables.get(var)));
				}else {
					System.out.println(variables.get(var));
				}
			}
			else {
				System.err.println("ERROR NO EXISTE LA VARIABLE "+var+" A PRINTEAR");
				System.exit(1);
			}
		}
		
		return 0;
	}
	
	@Override
	public Integer visitInput(ParserTParser.InputContext ctx) {
		//Validar si la variable existe o no
		String var = ctx.getChild(1).getText();
		if(variables.get(var) != null) {
			
			//Validar que la variable no sea estática
			if(variablesEstaticas.get(var)) {
				System.err.println("ERROR LA VARIABLE A LEER "+var+" ES ESTÁTICA");
				System.exit(1);
			}
			
			//Leer por la consola
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			String lectura = null;
			try {
	            lectura = reader.readLine();
	        } catch (IOException e) {
	            System.err.println("ERROR DE LECTURA EN LA CONSOLA");
	            System.exit(1);
	        }
			
			//Validar si la lectura es String o número
			if(isNumber(lectura)) {
				variables.put(var,lectura);
			}
			else {
				variables.put(var,("\""+lectura+"\""));
			}
			
		}
		else {
			System.err.println("ERROR NO EXISTE LA VARIABLE "+var+" A LEER");
			System.exit(1);
		}
		return 0;
	}
	
	@Override
	public Integer visitCond_if(ParserTParser.Cond_ifContext ctx) {
		//Realizar el condicional "Si...entonces..."
		if(afirmacion((ParserTParser.AfirmacionContext) ctx.getChild(1))) {
			visitChildren(ctx);
		}
		return 0;
	}
	
	@Override
	public Integer visitCicle_while(ParserTParser.Cicle_whileContext ctx) {
		//Realizar el ciclo "mientras...hacer"
		while(afirmacion((ParserTParser.AfirmacionContext) ctx.getChild(1))) {
			visitChildren(ctx);
		}
		return 0;
	}
	
	@Override 
	public Integer visitDowhile(ParserTParser.DowhileContext ctx) {
		//Realizar el ciclo "hacer...hasta que"
		do {
			visitChildren(ctx);
			if(afirmacion((ParserTParser.AfirmacionContext) ctx.getChild(3))) {
				break;
			}
			
		}while(true);
		
		return 0;
	}
	
}
