package ANTLR;

// Generated from ParserT.g4 by ANTLR 4.7.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class ParserTParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.7.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, T__16=17, 
		T__17=18, T__18=19, BEGIN=20, END=21, BEGINCONSTRUCCION=22, STRING=23, 
		VAR=24, INT=25, FLOAT=26, PI=27, FI=28, SUMAR=29, RESTAR=30, DIVIDIR=31, 
		MULTIPLICAR=32, RAIZ=33, SENO=34, COSENO=35, AND=36, OR=37, MAYOR=38, 
		MENOR=39, IGUAL=40, DISTINTO=41, WS=42;
	public static final int
		RULE_program = 0, RULE_materiales = 1, RULE_obrar = 2, RULE_objeto = 3, 
		RULE_entero = 4, RULE_decimal = 5, RULE_string = 6, RULE_declare_constante = 7, 
		RULE_constante = 8, RULE_statement = 9, RULE_resultado = 10, RULE_operacion = 11, 
		RULE_suma = 12, RULE_resta = 13, RULE_division = 14, RULE_multiplicacion = 15, 
		RULE_funcion = 16, RULE_afirmacion = 17, RULE_condicion = 18, RULE_mayor = 19, 
		RULE_menor = 20, RULE_igual = 21, RULE_distinto = 22, RULE_cond_if = 23, 
		RULE_repetitiva = 24, RULE_dowhile = 25, RULE_cicle_while = 26, RULE_in_out = 27, 
		RULE_input = 28, RULE_oracion = 29, RULE_output = 30;
	public static final String[] ruleNames = {
		"program", "materiales", "obrar", "objeto", "entero", "decimal", "string", 
		"declare_constante", "constante", "statement", "resultado", "operacion", 
		"suma", "resta", "division", "multiplicacion", "funcion", "afirmacion", 
		"condicion", "mayor", "menor", "igual", "distinto", "cond_if", "repetitiva", 
		"dowhile", "cicle_while", "in_out", "input", "oracion", "output"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "'kilos de'", "'usa'", "'Siempre'", "'da'", "'con'", "'de'", "'en'", 
		"'por cada'", "'que'", "'Si'", "', entonces'", "'continue'", "'Realizar:'", 
		"'Hasta que'", "'Mientras'", "'construir'", "'dejar de obrar'", "'El maestro pide comprar'", 
		"'El maestro dijo'", "'Comienzo de la jornada laboral'", "'Fin de la jornada'", 
		"'Al construir'", null, null, null, null, "'Pi'", "'Fi'", "'Mezclar'", 
		"'Separar'", "'Desarmar'", "'Combinar'", "'Cuadrar'", "'Centrar'", "'Cortar'", 
		"'y'", "'o'", "'haya mas'", "'haya menos'", "'haya los mismos'", "'no hayan los mismos'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, null, null, null, null, null, null, null, null, null, null, null, 
		null, null, null, null, null, null, null, null, "BEGIN", "END", "BEGINCONSTRUCCION", 
		"STRING", "VAR", "INT", "FLOAT", "PI", "FI", "SUMAR", "RESTAR", "DIVIDIR", 
		"MULTIPLICAR", "RAIZ", "SENO", "COSENO", "AND", "OR", "MAYOR", "MENOR", 
		"IGUAL", "DISTINTO", "WS"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "ParserT.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public ParserTParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class ProgramContext extends ParserRuleContext {
		public TerminalNode BEGIN() { return getToken(ParserTParser.BEGIN, 0); }
		public MaterialesContext materiales() {
			return getRuleContext(MaterialesContext.class,0);
		}
		public TerminalNode BEGINCONSTRUCCION() { return getToken(ParserTParser.BEGINCONSTRUCCION, 0); }
		public ObrarContext obrar() {
			return getRuleContext(ObrarContext.class,0);
		}
		public TerminalNode END() { return getToken(ParserTParser.END, 0); }
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitProgram(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(62);
			match(BEGIN);
			setState(63);
			materiales();
			setState(64);
			match(BEGINCONSTRUCCION);
			setState(65);
			obrar();
			setState(66);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MaterialesContext extends ParserRuleContext {
		public List<ObjetoContext> objeto() {
			return getRuleContexts(ObjetoContext.class);
		}
		public ObjetoContext objeto(int i) {
			return getRuleContext(ObjetoContext.class,i);
		}
		public MaterialesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_materiales; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitMateriales(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MaterialesContext materiales() throws RecognitionException {
		MaterialesContext _localctx = new MaterialesContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_materiales);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(71);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__2) | (1L << VAR) | (1L << INT) | (1L << FLOAT) | (1L << PI) | (1L << FI))) != 0)) {
				{
				{
				setState(68);
				objeto();
				}
				}
				setState(73);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ObrarContext extends ParserRuleContext {
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public ObrarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_obrar; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitObrar(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ObrarContext obrar() throws RecognitionException {
		ObrarContext _localctx = new ObrarContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_obrar);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(77);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__9) | (1L << T__12) | (1L << T__14) | (1L << T__17) | (1L << T__18) | (1L << SUMAR) | (1L << RESTAR) | (1L << DIVIDIR) | (1L << MULTIPLICAR) | (1L << RAIZ) | (1L << SENO) | (1L << COSENO))) != 0)) {
				{
				{
				setState(74);
				statement();
				}
				}
				setState(79);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ObjetoContext extends ParserRuleContext {
		public EnteroContext entero() {
			return getRuleContext(EnteroContext.class,0);
		}
		public DecimalContext decimal() {
			return getRuleContext(DecimalContext.class,0);
		}
		public StringContext string() {
			return getRuleContext(StringContext.class,0);
		}
		public Declare_constanteContext declare_constante() {
			return getRuleContext(Declare_constanteContext.class,0);
		}
		public ObjetoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_objeto; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitObjeto(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ObjetoContext objeto() throws RecognitionException {
		ObjetoContext _localctx = new ObjetoContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_objeto);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(81);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__2) {
				{
				setState(80);
				declare_constante();
				}
			}

			setState(86);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INT:
				{
				setState(83);
				entero();
				}
				break;
			case FLOAT:
			case PI:
			case FI:
				{
				setState(84);
				decimal();
				}
				break;
			case VAR:
				{
				setState(85);
				string();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EnteroContext extends ParserRuleContext {
		public TerminalNode INT() { return getToken(ParserTParser.INT, 0); }
		public TerminalNode VAR() { return getToken(ParserTParser.VAR, 0); }
		public EnteroContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entero; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitEntero(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EnteroContext entero() throws RecognitionException {
		EnteroContext _localctx = new EnteroContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_entero);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(88);
			match(INT);
			setState(89);
			match(VAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DecimalContext extends ParserRuleContext {
		public TerminalNode VAR() { return getToken(ParserTParser.VAR, 0); }
		public TerminalNode FLOAT() { return getToken(ParserTParser.FLOAT, 0); }
		public ConstanteContext constante() {
			return getRuleContext(ConstanteContext.class,0);
		}
		public DecimalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_decimal; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitDecimal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DecimalContext decimal() throws RecognitionException {
		DecimalContext _localctx = new DecimalContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_decimal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(93);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case FLOAT:
				{
				setState(91);
				match(FLOAT);
				}
				break;
			case PI:
			case FI:
				{
				setState(92);
				constante();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(95);
			match(T__0);
			setState(96);
			match(VAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringContext extends ParserRuleContext {
		public TerminalNode VAR() { return getToken(ParserTParser.VAR, 0); }
		public TerminalNode STRING() { return getToken(ParserTParser.STRING, 0); }
		public StringContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_string; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitString(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringContext string() throws RecognitionException {
		StringContext _localctx = new StringContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_string);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(98);
			match(VAR);
			setState(99);
			match(T__1);
			setState(100);
			match(STRING);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Declare_constanteContext extends ParserRuleContext {
		public Declare_constanteContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declare_constante; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitDeclare_constante(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Declare_constanteContext declare_constante() throws RecognitionException {
		Declare_constanteContext _localctx = new Declare_constanteContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_declare_constante);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(102);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConstanteContext extends ParserRuleContext {
		public TerminalNode PI() { return getToken(ParserTParser.PI, 0); }
		public TerminalNode FI() { return getToken(ParserTParser.FI, 0); }
		public ConstanteContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constante; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitConstante(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConstanteContext constante() throws RecognitionException {
		ConstanteContext _localctx = new ConstanteContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_constante);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(104);
			_la = _input.LA(1);
			if ( !(_la==PI || _la==FI) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatementContext extends ParserRuleContext {
		public OperacionContext operacion() {
			return getRuleContext(OperacionContext.class,0);
		}
		public Cond_ifContext cond_if() {
			return getRuleContext(Cond_ifContext.class,0);
		}
		public RepetitivaContext repetitiva() {
			return getRuleContext(RepetitivaContext.class,0);
		}
		public FuncionContext funcion() {
			return getRuleContext(FuncionContext.class,0);
		}
		public In_outContext in_out() {
			return getRuleContext(In_outContext.class,0);
		}
		public StatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statement; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StatementContext statement() throws RecognitionException {
		StatementContext _localctx = new StatementContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_statement);
		try {
			setState(111);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SUMAR:
			case RESTAR:
			case DIVIDIR:
			case MULTIPLICAR:
				enterOuterAlt(_localctx, 1);
				{
				setState(106);
				operacion();
				}
				break;
			case T__9:
				enterOuterAlt(_localctx, 2);
				{
				setState(107);
				cond_if();
				}
				break;
			case T__12:
			case T__14:
				enterOuterAlt(_localctx, 3);
				{
				setState(108);
				repetitiva();
				}
				break;
			case RAIZ:
			case SENO:
			case COSENO:
				enterOuterAlt(_localctx, 4);
				{
				setState(109);
				funcion();
				}
				break;
			case T__17:
			case T__18:
				enterOuterAlt(_localctx, 5);
				{
				setState(110);
				in_out();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ResultadoContext extends ParserRuleContext {
		public TerminalNode VAR() { return getToken(ParserTParser.VAR, 0); }
		public ResultadoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_resultado; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitResultado(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ResultadoContext resultado() throws RecognitionException {
		ResultadoContext _localctx = new ResultadoContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_resultado);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(113);
			match(T__3);
			setState(114);
			match(VAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OperacionContext extends ParserRuleContext {
		public SumaContext suma() {
			return getRuleContext(SumaContext.class,0);
		}
		public RestaContext resta() {
			return getRuleContext(RestaContext.class,0);
		}
		public DivisionContext division() {
			return getRuleContext(DivisionContext.class,0);
		}
		public MultiplicacionContext multiplicacion() {
			return getRuleContext(MultiplicacionContext.class,0);
		}
		public OperacionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_operacion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitOperacion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OperacionContext operacion() throws RecognitionException {
		OperacionContext _localctx = new OperacionContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_operacion);
		try {
			setState(120);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SUMAR:
				enterOuterAlt(_localctx, 1);
				{
				setState(116);
				suma();
				}
				break;
			case RESTAR:
				enterOuterAlt(_localctx, 2);
				{
				setState(117);
				resta();
				}
				break;
			case DIVIDIR:
				enterOuterAlt(_localctx, 3);
				{
				setState(118);
				division();
				}
				break;
			case MULTIPLICAR:
				enterOuterAlt(_localctx, 4);
				{
				setState(119);
				multiplicacion();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SumaContext extends ParserRuleContext {
		public TerminalNode SUMAR() { return getToken(ParserTParser.SUMAR, 0); }
		public List<TerminalNode> VAR() { return getTokens(ParserTParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ParserTParser.VAR, i);
		}
		public ResultadoContext resultado() {
			return getRuleContext(ResultadoContext.class,0);
		}
		public SumaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_suma; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitSuma(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SumaContext suma() throws RecognitionException {
		SumaContext _localctx = new SumaContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_suma);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(122);
			match(SUMAR);
			setState(123);
			match(VAR);
			setState(124);
			match(T__4);
			setState(125);
			match(VAR);
			setState(127);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__3) {
				{
				setState(126);
				resultado();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RestaContext extends ParserRuleContext {
		public TerminalNode RESTAR() { return getToken(ParserTParser.RESTAR, 0); }
		public List<TerminalNode> VAR() { return getTokens(ParserTParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ParserTParser.VAR, i);
		}
		public ResultadoContext resultado() {
			return getRuleContext(ResultadoContext.class,0);
		}
		public RestaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_resta; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitResta(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RestaContext resta() throws RecognitionException {
		RestaContext _localctx = new RestaContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_resta);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(129);
			match(RESTAR);
			setState(130);
			match(VAR);
			setState(131);
			match(T__5);
			setState(132);
			match(VAR);
			setState(134);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__3) {
				{
				setState(133);
				resultado();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DivisionContext extends ParserRuleContext {
		public TerminalNode DIVIDIR() { return getToken(ParserTParser.DIVIDIR, 0); }
		public List<TerminalNode> VAR() { return getTokens(ParserTParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ParserTParser.VAR, i);
		}
		public ResultadoContext resultado() {
			return getRuleContext(ResultadoContext.class,0);
		}
		public DivisionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_division; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitDivision(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DivisionContext division() throws RecognitionException {
		DivisionContext _localctx = new DivisionContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_division);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(136);
			match(DIVIDIR);
			setState(137);
			match(VAR);
			setState(138);
			match(T__6);
			setState(139);
			match(VAR);
			setState(141);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__3) {
				{
				setState(140);
				resultado();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MultiplicacionContext extends ParserRuleContext {
		public TerminalNode MULTIPLICAR() { return getToken(ParserTParser.MULTIPLICAR, 0); }
		public List<TerminalNode> VAR() { return getTokens(ParserTParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ParserTParser.VAR, i);
		}
		public ResultadoContext resultado() {
			return getRuleContext(ResultadoContext.class,0);
		}
		public MultiplicacionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_multiplicacion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitMultiplicacion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MultiplicacionContext multiplicacion() throws RecognitionException {
		MultiplicacionContext _localctx = new MultiplicacionContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_multiplicacion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(143);
			match(MULTIPLICAR);
			setState(144);
			match(VAR);
			setState(145);
			match(T__7);
			setState(146);
			match(VAR);
			setState(148);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__3) {
				{
				setState(147);
				resultado();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FuncionContext extends ParserRuleContext {
		public TerminalNode VAR() { return getToken(ParserTParser.VAR, 0); }
		public TerminalNode RAIZ() { return getToken(ParserTParser.RAIZ, 0); }
		public TerminalNode SENO() { return getToken(ParserTParser.SENO, 0); }
		public TerminalNode COSENO() { return getToken(ParserTParser.COSENO, 0); }
		public ResultadoContext resultado() {
			return getRuleContext(ResultadoContext.class,0);
		}
		public FuncionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_funcion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitFuncion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FuncionContext funcion() throws RecognitionException {
		FuncionContext _localctx = new FuncionContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_funcion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(150);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << RAIZ) | (1L << SENO) | (1L << COSENO))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(151);
			match(VAR);
			setState(153);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__3) {
				{
				setState(152);
				resultado();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AfirmacionContext extends ParserRuleContext {
		public List<CondicionContext> condicion() {
			return getRuleContexts(CondicionContext.class);
		}
		public CondicionContext condicion(int i) {
			return getRuleContext(CondicionContext.class,i);
		}
		public List<TerminalNode> AND() { return getTokens(ParserTParser.AND); }
		public TerminalNode AND(int i) {
			return getToken(ParserTParser.AND, i);
		}
		public List<TerminalNode> OR() { return getTokens(ParserTParser.OR); }
		public TerminalNode OR(int i) {
			return getToken(ParserTParser.OR, i);
		}
		public AfirmacionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_afirmacion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitAfirmacion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AfirmacionContext afirmacion() throws RecognitionException {
		AfirmacionContext _localctx = new AfirmacionContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_afirmacion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(155);
			condicion();
			setState(160);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==AND || _la==OR) {
				{
				{
				setState(156);
				_la = _input.LA(1);
				if ( !(_la==AND || _la==OR) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(157);
				condicion();
				}
				}
				setState(162);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CondicionContext extends ParserRuleContext {
		public MayorContext mayor() {
			return getRuleContext(MayorContext.class,0);
		}
		public MenorContext menor() {
			return getRuleContext(MenorContext.class,0);
		}
		public IgualContext igual() {
			return getRuleContext(IgualContext.class,0);
		}
		public DistintoContext distinto() {
			return getRuleContext(DistintoContext.class,0);
		}
		public CondicionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condicion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitCondicion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CondicionContext condicion() throws RecognitionException {
		CondicionContext _localctx = new CondicionContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_condicion);
		try {
			setState(167);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case MAYOR:
				enterOuterAlt(_localctx, 1);
				{
				setState(163);
				mayor();
				}
				break;
			case MENOR:
				enterOuterAlt(_localctx, 2);
				{
				setState(164);
				menor();
				}
				break;
			case IGUAL:
				enterOuterAlt(_localctx, 3);
				{
				setState(165);
				igual();
				}
				break;
			case DISTINTO:
				enterOuterAlt(_localctx, 4);
				{
				setState(166);
				distinto();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MayorContext extends ParserRuleContext {
		public TerminalNode MAYOR() { return getToken(ParserTParser.MAYOR, 0); }
		public List<TerminalNode> VAR() { return getTokens(ParserTParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ParserTParser.VAR, i);
		}
		public MayorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mayor; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitMayor(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MayorContext mayor() throws RecognitionException {
		MayorContext _localctx = new MayorContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_mayor);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(169);
			match(MAYOR);
			setState(170);
			match(VAR);
			setState(171);
			match(T__8);
			setState(172);
			match(VAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MenorContext extends ParserRuleContext {
		public TerminalNode MENOR() { return getToken(ParserTParser.MENOR, 0); }
		public List<TerminalNode> VAR() { return getTokens(ParserTParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ParserTParser.VAR, i);
		}
		public MenorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_menor; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitMenor(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MenorContext menor() throws RecognitionException {
		MenorContext _localctx = new MenorContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_menor);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(174);
			match(MENOR);
			setState(175);
			match(VAR);
			setState(176);
			match(T__8);
			setState(177);
			match(VAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IgualContext extends ParserRuleContext {
		public TerminalNode IGUAL() { return getToken(ParserTParser.IGUAL, 0); }
		public List<TerminalNode> VAR() { return getTokens(ParserTParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ParserTParser.VAR, i);
		}
		public IgualContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_igual; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitIgual(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IgualContext igual() throws RecognitionException {
		IgualContext _localctx = new IgualContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_igual);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(179);
			match(IGUAL);
			setState(180);
			match(VAR);
			setState(181);
			match(T__8);
			setState(182);
			match(VAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DistintoContext extends ParserRuleContext {
		public TerminalNode DISTINTO() { return getToken(ParserTParser.DISTINTO, 0); }
		public List<TerminalNode> VAR() { return getTokens(ParserTParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(ParserTParser.VAR, i);
		}
		public DistintoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_distinto; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitDistinto(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DistintoContext distinto() throws RecognitionException {
		DistintoContext _localctx = new DistintoContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_distinto);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(184);
			match(DISTINTO);
			setState(185);
			match(VAR);
			setState(186);
			match(T__8);
			setState(187);
			match(VAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Cond_ifContext extends ParserRuleContext {
		public AfirmacionContext afirmacion() {
			return getRuleContext(AfirmacionContext.class,0);
		}
		public ObrarContext obrar() {
			return getRuleContext(ObrarContext.class,0);
		}
		public Cond_ifContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cond_if; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitCond_if(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Cond_ifContext cond_if() throws RecognitionException {
		Cond_ifContext _localctx = new Cond_ifContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_cond_if);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(189);
			match(T__9);
			setState(190);
			afirmacion();
			setState(191);
			match(T__10);
			setState(192);
			obrar();
			setState(193);
			match(T__11);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RepetitivaContext extends ParserRuleContext {
		public DowhileContext dowhile() {
			return getRuleContext(DowhileContext.class,0);
		}
		public Cicle_whileContext cicle_while() {
			return getRuleContext(Cicle_whileContext.class,0);
		}
		public RepetitivaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_repetitiva; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitRepetitiva(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RepetitivaContext repetitiva() throws RecognitionException {
		RepetitivaContext _localctx = new RepetitivaContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_repetitiva);
		try {
			setState(197);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__12:
				enterOuterAlt(_localctx, 1);
				{
				setState(195);
				dowhile();
				}
				break;
			case T__14:
				enterOuterAlt(_localctx, 2);
				{
				setState(196);
				cicle_while();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DowhileContext extends ParserRuleContext {
		public ObrarContext obrar() {
			return getRuleContext(ObrarContext.class,0);
		}
		public AfirmacionContext afirmacion() {
			return getRuleContext(AfirmacionContext.class,0);
		}
		public DowhileContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dowhile; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitDowhile(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DowhileContext dowhile() throws RecognitionException {
		DowhileContext _localctx = new DowhileContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_dowhile);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(199);
			match(T__12);
			setState(200);
			obrar();
			setState(201);
			match(T__13);
			setState(202);
			afirmacion();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Cicle_whileContext extends ParserRuleContext {
		public AfirmacionContext afirmacion() {
			return getRuleContext(AfirmacionContext.class,0);
		}
		public ObrarContext obrar() {
			return getRuleContext(ObrarContext.class,0);
		}
		public Cicle_whileContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cicle_while; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitCicle_while(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Cicle_whileContext cicle_while() throws RecognitionException {
		Cicle_whileContext _localctx = new Cicle_whileContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_cicle_while);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(204);
			match(T__14);
			setState(205);
			afirmacion();
			setState(206);
			match(T__15);
			setState(207);
			obrar();
			setState(208);
			match(T__16);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class In_outContext extends ParserRuleContext {
		public InputContext input() {
			return getRuleContext(InputContext.class,0);
		}
		public OutputContext output() {
			return getRuleContext(OutputContext.class,0);
		}
		public In_outContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_in_out; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitIn_out(this);
			else return visitor.visitChildren(this);
		}
	}

	public final In_outContext in_out() throws RecognitionException {
		In_outContext _localctx = new In_outContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_in_out);
		try {
			setState(212);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__17:
				enterOuterAlt(_localctx, 1);
				{
				setState(210);
				input();
				}
				break;
			case T__18:
				enterOuterAlt(_localctx, 2);
				{
				setState(211);
				output();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InputContext extends ParserRuleContext {
		public TerminalNode VAR() { return getToken(ParserTParser.VAR, 0); }
		public InputContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_input; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitInput(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InputContext input() throws RecognitionException {
		InputContext _localctx = new InputContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_input);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(214);
			match(T__17);
			setState(215);
			match(VAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OracionContext extends ParserRuleContext {
		public TerminalNode STRING() { return getToken(ParserTParser.STRING, 0); }
		public TerminalNode VAR() { return getToken(ParserTParser.VAR, 0); }
		public OracionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_oracion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitOracion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OracionContext oracion() throws RecognitionException {
		OracionContext _localctx = new OracionContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_oracion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(217);
			_la = _input.LA(1);
			if ( !(_la==STRING || _la==VAR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OutputContext extends ParserRuleContext {
		public OracionContext oracion() {
			return getRuleContext(OracionContext.class,0);
		}
		public OutputContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_output; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof ParserTVisitor ) return ((ParserTVisitor<? extends T>)visitor).visitOutput(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OutputContext output() throws RecognitionException {
		OutputContext _localctx = new OutputContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_output);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(219);
			match(T__18);
			setState(220);
			oracion();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3,\u00e1\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t \3\2"+
		"\3\2\3\2\3\2\3\2\3\2\3\3\7\3H\n\3\f\3\16\3K\13\3\3\4\7\4N\n\4\f\4\16\4"+
		"Q\13\4\3\5\5\5T\n\5\3\5\3\5\3\5\5\5Y\n\5\3\6\3\6\3\6\3\7\3\7\5\7`\n\7"+
		"\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3\t\3\t\3\n\3\n\3\13\3\13\3\13\3\13\3\13"+
		"\5\13r\n\13\3\f\3\f\3\f\3\r\3\r\3\r\3\r\5\r{\n\r\3\16\3\16\3\16\3\16\3"+
		"\16\5\16\u0082\n\16\3\17\3\17\3\17\3\17\3\17\5\17\u0089\n\17\3\20\3\20"+
		"\3\20\3\20\3\20\5\20\u0090\n\20\3\21\3\21\3\21\3\21\3\21\5\21\u0097\n"+
		"\21\3\22\3\22\3\22\5\22\u009c\n\22\3\23\3\23\3\23\7\23\u00a1\n\23\f\23"+
		"\16\23\u00a4\13\23\3\24\3\24\3\24\3\24\5\24\u00aa\n\24\3\25\3\25\3\25"+
		"\3\25\3\25\3\26\3\26\3\26\3\26\3\26\3\27\3\27\3\27\3\27\3\27\3\30\3\30"+
		"\3\30\3\30\3\30\3\31\3\31\3\31\3\31\3\31\3\31\3\32\3\32\5\32\u00c8\n\32"+
		"\3\33\3\33\3\33\3\33\3\33\3\34\3\34\3\34\3\34\3\34\3\34\3\35\3\35\5\35"+
		"\u00d7\n\35\3\36\3\36\3\36\3\37\3\37\3 \3 \3 \3 \2\2!\2\4\6\b\n\f\16\20"+
		"\22\24\26\30\32\34\36 \"$&(*,.\60\62\64\668:<>\2\6\3\2\35\36\3\2#%\3\2"+
		"&\'\3\2\31\32\2\u00d9\2@\3\2\2\2\4I\3\2\2\2\6O\3\2\2\2\bS\3\2\2\2\nZ\3"+
		"\2\2\2\f_\3\2\2\2\16d\3\2\2\2\20h\3\2\2\2\22j\3\2\2\2\24q\3\2\2\2\26s"+
		"\3\2\2\2\30z\3\2\2\2\32|\3\2\2\2\34\u0083\3\2\2\2\36\u008a\3\2\2\2 \u0091"+
		"\3\2\2\2\"\u0098\3\2\2\2$\u009d\3\2\2\2&\u00a9\3\2\2\2(\u00ab\3\2\2\2"+
		"*\u00b0\3\2\2\2,\u00b5\3\2\2\2.\u00ba\3\2\2\2\60\u00bf\3\2\2\2\62\u00c7"+
		"\3\2\2\2\64\u00c9\3\2\2\2\66\u00ce\3\2\2\28\u00d6\3\2\2\2:\u00d8\3\2\2"+
		"\2<\u00db\3\2\2\2>\u00dd\3\2\2\2@A\7\26\2\2AB\5\4\3\2BC\7\30\2\2CD\5\6"+
		"\4\2DE\7\27\2\2E\3\3\2\2\2FH\5\b\5\2GF\3\2\2\2HK\3\2\2\2IG\3\2\2\2IJ\3"+
		"\2\2\2J\5\3\2\2\2KI\3\2\2\2LN\5\24\13\2ML\3\2\2\2NQ\3\2\2\2OM\3\2\2\2"+
		"OP\3\2\2\2P\7\3\2\2\2QO\3\2\2\2RT\5\20\t\2SR\3\2\2\2ST\3\2\2\2TX\3\2\2"+
		"\2UY\5\n\6\2VY\5\f\7\2WY\5\16\b\2XU\3\2\2\2XV\3\2\2\2XW\3\2\2\2Y\t\3\2"+
		"\2\2Z[\7\33\2\2[\\\7\32\2\2\\\13\3\2\2\2]`\7\34\2\2^`\5\22\n\2_]\3\2\2"+
		"\2_^\3\2\2\2`a\3\2\2\2ab\7\3\2\2bc\7\32\2\2c\r\3\2\2\2de\7\32\2\2ef\7"+
		"\4\2\2fg\7\31\2\2g\17\3\2\2\2hi\7\5\2\2i\21\3\2\2\2jk\t\2\2\2k\23\3\2"+
		"\2\2lr\5\30\r\2mr\5\60\31\2nr\5\62\32\2or\5\"\22\2pr\58\35\2ql\3\2\2\2"+
		"qm\3\2\2\2qn\3\2\2\2qo\3\2\2\2qp\3\2\2\2r\25\3\2\2\2st\7\6\2\2tu\7\32"+
		"\2\2u\27\3\2\2\2v{\5\32\16\2w{\5\34\17\2x{\5\36\20\2y{\5 \21\2zv\3\2\2"+
		"\2zw\3\2\2\2zx\3\2\2\2zy\3\2\2\2{\31\3\2\2\2|}\7\37\2\2}~\7\32\2\2~\177"+
		"\7\7\2\2\177\u0081\7\32\2\2\u0080\u0082\5\26\f\2\u0081\u0080\3\2\2\2\u0081"+
		"\u0082\3\2\2\2\u0082\33\3\2\2\2\u0083\u0084\7 \2\2\u0084\u0085\7\32\2"+
		"\2\u0085\u0086\7\b\2\2\u0086\u0088\7\32\2\2\u0087\u0089\5\26\f\2\u0088"+
		"\u0087\3\2\2\2\u0088\u0089\3\2\2\2\u0089\35\3\2\2\2\u008a\u008b\7!\2\2"+
		"\u008b\u008c\7\32\2\2\u008c\u008d\7\t\2\2\u008d\u008f\7\32\2\2\u008e\u0090"+
		"\5\26\f\2\u008f\u008e\3\2\2\2\u008f\u0090\3\2\2\2\u0090\37\3\2\2\2\u0091"+
		"\u0092\7\"\2\2\u0092\u0093\7\32\2\2\u0093\u0094\7\n\2\2\u0094\u0096\7"+
		"\32\2\2\u0095\u0097\5\26\f\2\u0096\u0095\3\2\2\2\u0096\u0097\3\2\2\2\u0097"+
		"!\3\2\2\2\u0098\u0099\t\3\2\2\u0099\u009b\7\32\2\2\u009a\u009c\5\26\f"+
		"\2\u009b\u009a\3\2\2\2\u009b\u009c\3\2\2\2\u009c#\3\2\2\2\u009d\u00a2"+
		"\5&\24\2\u009e\u009f\t\4\2\2\u009f\u00a1\5&\24\2\u00a0\u009e\3\2\2\2\u00a1"+
		"\u00a4\3\2\2\2\u00a2\u00a0\3\2\2\2\u00a2\u00a3\3\2\2\2\u00a3%\3\2\2\2"+
		"\u00a4\u00a2\3\2\2\2\u00a5\u00aa\5(\25\2\u00a6\u00aa\5*\26\2\u00a7\u00aa"+
		"\5,\27\2\u00a8\u00aa\5.\30\2\u00a9\u00a5\3\2\2\2\u00a9\u00a6\3\2\2\2\u00a9"+
		"\u00a7\3\2\2\2\u00a9\u00a8\3\2\2\2\u00aa\'\3\2\2\2\u00ab\u00ac\7(\2\2"+
		"\u00ac\u00ad\7\32\2\2\u00ad\u00ae\7\13\2\2\u00ae\u00af\7\32\2\2\u00af"+
		")\3\2\2\2\u00b0\u00b1\7)\2\2\u00b1\u00b2\7\32\2\2\u00b2\u00b3\7\13\2\2"+
		"\u00b3\u00b4\7\32\2\2\u00b4+\3\2\2\2\u00b5\u00b6\7*\2\2\u00b6\u00b7\7"+
		"\32\2\2\u00b7\u00b8\7\13\2\2\u00b8\u00b9\7\32\2\2\u00b9-\3\2\2\2\u00ba"+
		"\u00bb\7+\2\2\u00bb\u00bc\7\32\2\2\u00bc\u00bd\7\13\2\2\u00bd\u00be\7"+
		"\32\2\2\u00be/\3\2\2\2\u00bf\u00c0\7\f\2\2\u00c0\u00c1\5$\23\2\u00c1\u00c2"+
		"\7\r\2\2\u00c2\u00c3\5\6\4\2\u00c3\u00c4\7\16\2\2\u00c4\61\3\2\2\2\u00c5"+
		"\u00c8\5\64\33\2\u00c6\u00c8\5\66\34\2\u00c7\u00c5\3\2\2\2\u00c7\u00c6"+
		"\3\2\2\2\u00c8\63\3\2\2\2\u00c9\u00ca\7\17\2\2\u00ca\u00cb\5\6\4\2\u00cb"+
		"\u00cc\7\20\2\2\u00cc\u00cd\5$\23\2\u00cd\65\3\2\2\2\u00ce\u00cf\7\21"+
		"\2\2\u00cf\u00d0\5$\23\2\u00d0\u00d1\7\22\2\2\u00d1\u00d2\5\6\4\2\u00d2"+
		"\u00d3\7\23\2\2\u00d3\67\3\2\2\2\u00d4\u00d7\5:\36\2\u00d5\u00d7\5> \2"+
		"\u00d6\u00d4\3\2\2\2\u00d6\u00d5\3\2\2\2\u00d79\3\2\2\2\u00d8\u00d9\7"+
		"\24\2\2\u00d9\u00da\7\32\2\2\u00da;\3\2\2\2\u00db\u00dc\t\5\2\2\u00dc"+
		"=\3\2\2\2\u00dd\u00de\7\25\2\2\u00de\u00df\5<\37\2\u00df?\3\2\2\2\22I"+
		"OSX_qz\u0081\u0088\u008f\u0096\u009b\u00a2\u00a9\u00c7\u00d6";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}