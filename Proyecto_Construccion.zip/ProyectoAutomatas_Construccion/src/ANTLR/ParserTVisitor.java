package ANTLR;

// Generated from ParserT.g4 by ANTLR 4.7.1
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link ParserTParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface ParserTVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link ParserTParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(ParserTParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#materiales}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMateriales(ParserTParser.MaterialesContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#obrar}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitObrar(ParserTParser.ObrarContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#objeto}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitObjeto(ParserTParser.ObjetoContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#entero}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEntero(ParserTParser.EnteroContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#decimal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecimal(ParserTParser.DecimalContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#string}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitString(ParserTParser.StringContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#declare_constante}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclare_constante(ParserTParser.Declare_constanteContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#constante}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstante(ParserTParser.ConstanteContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStatement(ParserTParser.StatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#resultado}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitResultado(ParserTParser.ResultadoContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#operacion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperacion(ParserTParser.OperacionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#suma}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSuma(ParserTParser.SumaContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#resta}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitResta(ParserTParser.RestaContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#division}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDivision(ParserTParser.DivisionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#multiplicacion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultiplicacion(ParserTParser.MultiplicacionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#funcion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncion(ParserTParser.FuncionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#afirmacion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAfirmacion(ParserTParser.AfirmacionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#condicion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondicion(ParserTParser.CondicionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#mayor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMayor(ParserTParser.MayorContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#menor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMenor(ParserTParser.MenorContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#igual}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIgual(ParserTParser.IgualContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#distinto}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDistinto(ParserTParser.DistintoContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#cond_if}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCond_if(ParserTParser.Cond_ifContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#repetitiva}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRepetitiva(ParserTParser.RepetitivaContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#dowhile}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDowhile(ParserTParser.DowhileContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#cicle_while}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCicle_while(ParserTParser.Cicle_whileContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#in_out}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIn_out(ParserTParser.In_outContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#input}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInput(ParserTParser.InputContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#oracion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOracion(ParserTParser.OracionContext ctx);
	/**
	 * Visit a parse tree produced by {@link ParserTParser#output}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOutput(ParserTParser.OutputContext ctx);
}